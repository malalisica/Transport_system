package model;

public enum ResponsibilityManagers {
    MANAGER_1, MANAGER_2;

    private ResponsibilityManagers() {

    }


}
