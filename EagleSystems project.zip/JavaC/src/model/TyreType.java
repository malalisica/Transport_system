package model;

public enum TyreType {
    TYRE_1, TYRE_2;

    private TyreType() {
        
    }
}

