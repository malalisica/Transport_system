package model;

public enum CargoType {

    ALCOHOL, PAPER, MIX, CONSUMER_ELECTRONICS, FOOD;


}
