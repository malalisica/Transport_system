package fxControllers;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import model.Cargo;
import model.CargoType;
import model.Checkpoint;
import model.Destination;
import model.Driver;
import model.Manager;
import model.Truck;
import model.TyreType;
import model.User;
import utils.DbUtils;
import utils.fxUtils;

public class Main implements Initializable {
    @FXML
    public TextField odometerField;
    @FXML
    public TextField tankCapacityField;
    @FXML
    public TextField makeField;
    @FXML
    public TextField modelField;
    @FXML
    public TextField yearField;
    @FXML
    public ComboBox<TyreType> tyreTypeField;
    @FXML
    public ListView<Truck> truckListField;
    @FXML
    public TextField titleField;
    @FXML
    public TextField weightField;
    @FXML
    public TextField customerField;
    @FXML
    public DatePicker dateCreatedField;
    @FXML
    public TextArea descriptionField;
    @FXML
    public ComboBox<CargoType> cargoTypeField;
    @FXML
    public ListView<Cargo> cargoListField;
    @FXML
    public TextField startLocField;
    @FXML
    public TextField longitudeStartField;
    @FXML
    public TextField latitudeStartField;
    @FXML
    public TextField destinationLocField;
    @FXML
    public TextField destinationLongitudeField;
    @FXML
    public TextField destinationLatitudeField;
    @FXML
    public ListView<Destination> destinationListField;
    @FXML
    public TextField checkpointLocField;
    @FXML
    public RadioButton radioShort;
    @FXML
    public RadioButton radioLong;
    @FXML
    public ListView<Checkpoint> checkpointListField;
    @FXML
    public ToggleGroup checkpointType;
    @FXML
    public TableColumn<Driver, Integer> d_id;
    @FXML
    public TableColumn<Driver, String> d_login;
    @FXML
    public TableColumn<Driver, String> d_name;
    @FXML
    public TableColumn<Driver, String> d_surname;
    @FXML
    public TableColumn<Driver, Date> d_birthdate;
    @FXML
    public TableColumn<Driver, String> d_phoneNumber;
    @FXML
    public TableColumn<Driver, LocalDate> d_medCertificateDate;
    @FXML
    public TableColumn<Driver, String> d_medCertificateNumber;
    @FXML
    public TableColumn<Driver, String> d_driverLicence;
    @FXML
    public TableColumn<Manager, Integer> m_id;
    @FXML
    public TableColumn<Manager, String> m_login;
    @FXML
    public TableColumn<Manager, String> m_name;
    @FXML
    public TableColumn<Manager, String> m_surname;
    @FXML
    public TableColumn<Manager, String> m_phoneNumber;
    @FXML
    public TableColumn<Manager, String> m_email;
    @FXML
    public TableColumn<Manager, LocalDate> m_employmentDate;
    @FXML
    public TableView<Driver> driverTable;
    @FXML
    public TableColumn<Manager, LocalDate> m_birthdate;
    @FXML
    public TableView<Manager> managerTable;
    @FXML
    public ComboBox<Manager> responsibilityManager;
    @FXML
    public DatePicker destinationDateCreatedField;
    @FXML
    public ComboBox<Cargo> cargoComboBoxAvailable;
    @FXML
    public ComboBox<Truck> truckComboBoxAvailable;
    @FXML
    ObservableList<Driver> listD;
    ObservableList<Manager> listM;
    @FXML
    private User loggedUser;


    public void setInfo(User user) {
        this.loggedUser = user;
    }

    public void initialize(URL location, ResourceBundle resources) {
        try {
            this.cargoComboBoxAvailable.setItems(DbUtils.getDataCargo());
            this.cargoComboBoxAvailable.getSelectionModel().select(0);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        try {
            this.truckComboBoxAvailable.setItems(DbUtils.getDataTruck());
            this.truckComboBoxAvailable.getSelectionModel().select(0);
        } catch (ClassNotFoundException var10) {
            throw new RuntimeException(var10);
        }

        this.radioLong.setSelected(true);
        this.d_id.setCellValueFactory(new PropertyValueFactory<>("id"));
        this.d_login.setCellValueFactory(new PropertyValueFactory<>("login"));
        this.d_name.setCellValueFactory(new PropertyValueFactory<>("name"));
        this.d_surname.setCellValueFactory(new PropertyValueFactory<>("surname"));
        this.d_birthdate.setCellValueFactory(new PropertyValueFactory<>("birthDate"));
        this.d_phoneNumber.setCellValueFactory(new PropertyValueFactory<>("phoneNum"));
        this.d_medCertificateDate.setCellValueFactory(new PropertyValueFactory<>("medCertificateDate"));
        this.d_medCertificateNumber.setCellValueFactory(new PropertyValueFactory<>("medCertificateNumber"));
        this.d_driverLicence.setCellValueFactory(new PropertyValueFactory<>("driverLicense"));

        try {
            this.listD = DbUtils.getDataDrivers();
        } catch (ClassNotFoundException var9) {
            throw new RuntimeException(var9);
        }

        this.driverTable.setItems(this.listD);
        this.m_id.setCellValueFactory(new PropertyValueFactory<>("id"));
        this.m_login.setCellValueFactory(new PropertyValueFactory<>("login"));
        this.m_name.setCellValueFactory(new PropertyValueFactory<>("name"));
        this.m_surname.setCellValueFactory(new PropertyValueFactory<>("surname"));
        this.m_birthdate.setCellValueFactory(new PropertyValueFactory<>("birthDate"));
        this.m_phoneNumber.setCellValueFactory(new PropertyValueFactory<>("phoneNum"));
        this.m_email.setCellValueFactory(new PropertyValueFactory<>("email"));
        this.m_employmentDate.setCellValueFactory(new PropertyValueFactory<>("employmentDate"));

        try {
            this.listM = DbUtils.getDataManagers();
        } catch (ClassNotFoundException var8) {
            throw new RuntimeException(var8);
        }

        this.managerTable.setItems(this.listM);
        this.cargoTypeField.setItems(FXCollections.observableArrayList(CargoType.values()));
        this.cargoTypeField.getSelectionModel().select(0);
        this.tyreTypeField.setItems(FXCollections.observableArrayList(TyreType.values()));
        this.tyreTypeField.getSelectionModel().select(0);
        this.cargoTypeField.setItems(FXCollections.observableArrayList(CargoType.values()));
        this.cargoTypeField.getSelectionModel().select(0);

        try {
            this.responsibilityManager.setItems(DbUtils.getDataManagers());
            this.responsibilityManager.getSelectionModel().select(0);
        } catch (ClassNotFoundException var7) {
            throw new RuntimeException(var7);
        }

        try {
            this.destinationListField.setItems(DbUtils.getDataDestination());
        } catch (SQLException var6) {
            throw new RuntimeException(var6);
        }

        try {
            this.cargoListField.setItems(DbUtils.getDataCargo());
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        try {
            this.truckListField.setItems(DbUtils.getDataTruck());
        } catch (ClassNotFoundException var4) {
            throw new RuntimeException(var4);
        }
    }

    public void updateUserManagement() throws ClassNotFoundException {
        Connection conn = DbUtils.connectToDb();
        Driver selectedDriver = driverTable.getSelectionModel().getSelectedItem();
        if (selectedDriver != null) {
            TextField loginField = new TextField(selectedDriver.getLogin());
            TextField nameField = new TextField(selectedDriver.getName());
            TextField surnameField = new TextField(selectedDriver.getSurname());
            TextField med_numField = new TextField(selectedDriver.getMedCertificateNumber());
            TextField driver_licenceField = new TextField(selectedDriver.getDriverLicense());
            TextField phone_numberField = new TextField(selectedDriver.getPhoneNum());

            VBox vbox = new VBox(
                    new Label("Name:"), nameField,
                    new Label("Surname:"), surnameField,
                    new Label("Phone number"), phone_numberField,
                    new Label("Medical licence number"), med_numField,
                    new Label("Driver Licence"), driver_licenceField
            );
            fxUtils.updateItem(driverTable,
                    selectedDriver,
                    "Update Driver Information",
                    vbox,
                    () -> {
                        PreparedStatement ps = null;
                        try {
                            ps = conn.prepareStatement("UPDATE drivers SET name=?, surname=?, med_num=? ,driver_license=?, phone_num = ? WHERE login = ?");
                            ps.setString(1, nameField.getText());
                            ps.setString(2, surnameField.getText());
                            ps.setString(3, med_numField.getText());
                            ps.setString(4, driver_licenceField.getText());
                            ps.setString(5, phone_numberField.getText());
                            ps.setString(6, loginField.getText());
                            ps.executeUpdate();
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        }
                        fxUtils.throwAlert("Updating driver info", "Updated");
                    });
            listD = DbUtils.getDataDrivers();
            driverTable.setItems(listD);
        } else {
            Manager selectedManager = managerTable.getSelectionModel().getSelectedItem();
            TextField loginField = new TextField(selectedManager.getLogin());
            TextField nameField = new TextField(selectedManager.getName());
            TextField surnameField = new TextField(selectedManager.getSurname());
            TextField emailField = new TextField(selectedManager.getEmail());
            TextField phone_numberField = new TextField(selectedManager.getPhoneNum());

            VBox vbox = new VBox(
                    new Label("Name:"), nameField,
                    new Label("Surname:"), surnameField,
                    new Label("Phone number"), phone_numberField,
                    new Label("Email"), emailField
            );
            fxUtils.updateItem(managerTable,
                    selectedManager,
                    "Update manager information",
                    vbox,
                    () -> {
                        PreparedStatement ps = null;
                        try {
                            ps = conn.prepareStatement("UPDATE managers SET name=?, surname=?, phone_num = ?, email=? WHERE login = ?");
                            ps.setString(1, nameField.getText());
                            ps.setString(2, surnameField.getText());
                            ps.setString(3, phone_numberField.getText());
                            ps.setString(4, emailField.getText());
                            ps.setString(5, loginField.getText());
                            ps.executeUpdate();
                        } catch (SQLException e) {
                            throw new RuntimeException(e);
                        } finally {
                            DbUtils.disconnect(conn, ps);
                        }
                        fxUtils.throwAlert("Updating driver info", "Updated");
                    });
             listM= DbUtils.getDataManagers();
            managerTable.setItems(listM);
        }
    }

    public void deleteUserManagement() throws SQLException {
        Connection connection = DbUtils.connectToDb();
        Driver selectedDriver = (Driver)this.driverTable.getSelectionModel().getSelectedItem();
        Manager selectedManager = (Manager)this.managerTable.getSelectionModel().getSelectedItem();
        String loginDriver;
        PreparedStatement driverStmt;
        ObservableList driverList;
        if (selectedDriver != null) {
            loginDriver = selectedDriver.getLogin();
            driverStmt = connection.prepareStatement("DELETE FROM drivers WHERE login=?");
            driverStmt.setString(1, loginDriver);

            try {
                connection.setAutoCommit(false);
                driverStmt.executeUpdate();
                connection.commit();
                driverList = this.driverTable.getItems();
                driverList.remove(selectedDriver);
                this.driverTable.refresh();
            } catch (SQLException var19) {
                var19.printStackTrace();
                throw var19;
            } finally {
                connection.setAutoCommit(true);
                connection.close();
            }
        } else {
            loginDriver = selectedManager.getLogin();
            driverStmt = connection.prepareStatement("DELETE FROM managers WHERE login=?");
            driverStmt.setString(1, loginDriver);
            connection.setAutoCommit(false);

            try {
                connection.setAutoCommit(false);
                driverStmt.executeUpdate();
                driverList = this.managerTable.getItems();
                driverList.remove(selectedManager);
                this.managerTable.refresh();
            } catch (SQLException var17) {
                connection.rollback();
                throw var17;
            } finally {
                connection.setAutoCommit(true);
                connection.close();
            }
        }

    }

    public void createTruck() throws SQLException, ClassNotFoundException {
        try {
            if (!this.makeField.getText().isEmpty() && !this.modelField.getText().isEmpty() && !this.yearField.getText().isEmpty() && !this.odometerField.getText().isEmpty() && !this.tankCapacityField.getText().isEmpty()) {
                int year = Integer.parseInt(this.yearField.getText());
                double odometer = Double.parseDouble(this.odometerField.getText());
                double var4 = Double.parseDouble(this.tankCapacityField.getText());
            } else {
                LoginPage.alertDialog("Error", "All fields must be filled");
            }
        } catch (NumberFormatException var6) {
            LoginPage.alertDialog("Error", "Invalid input: " + var6.getMessage());
        }

        Connection connection = DbUtils.connectToDb();
        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO trucks(make, model, year, odometer, fuelTankCapacity, tyreType) VALUES (?,?,?,?,?,?)");
        preparedStatement.setString(1, this.makeField.getText());
        preparedStatement.setString(2, this.modelField.getText());
        preparedStatement.setInt(3, Integer.parseInt(this.yearField.getText()));
        preparedStatement.setDouble(4, Double.parseDouble(this.odometerField.getText()));
        preparedStatement.setDouble(5, Double.parseDouble(this.tankCapacityField.getText()));
        preparedStatement.setString(6, String.valueOf(this.tyreTypeField.getValue()));
        preparedStatement.execute();
        DbUtils.disconnect(connection, preparedStatement);
        this.truckListField.setItems(DbUtils.getDataTruck());
        this.truckComboBoxAvailable.setItems(DbUtils.getDataTruck());
    }

    public void updateTruck() {
        Connection conn = DbUtils.connectToDb();
        Truck selectedTruck = (Truck)this.truckListField.getSelectionModel().getSelectedItem();
        if (selectedTruck != null) {
            TextField makeField = new TextField(selectedTruck.getMake());
            TextField modelField = new TextField(selectedTruck.getModel());
            TextField yearField = new TextField(Integer.toString(selectedTruck.getYear()));
            TextField odometerField = new TextField(Double.toString(selectedTruck.getOdometer()));
            TextField fuelCapacityField = new TextField(Double.toString(selectedTruck.getFuelTankCapacity()));
            ComboBox<TyreType> tyreTypeBox = new ComboBox<>();
            tyreTypeBox.getItems().addAll(TyreType.values());
            tyreTypeBox.setValue(selectedTruck.getTypeType());
            VBox vbox = new VBox(new Label("Make:"), makeField, new Label("Model:"), modelField, new Label("Year:"), yearField, new Label("Odometer:"), odometerField, new Label("Fuel Tank Capacity:"), fuelCapacityField, new Label("Tyre Type:"), tyreTypeBox);
            fxUtils.updateItem(this.truckListField, selectedTruck, "Update Truck Information", vbox, () -> {
                PreparedStatement ps = null;

                try {
                    ps = conn.prepareStatement("UPDATE trucks SET make=? , model =?,year = ? , odometer =?,fuelTankCapacity=?,tyreType =? WHERE id = ?");
                    ps.setString(1, makeField.getText());
                    ps.setString(2, modelField.getText());
                    ps.setInt(3, Integer.parseInt(yearField.getText()));
                    ps.setDouble(4, Double.parseDouble(odometerField.getText()));
                    ps.setDouble(5, Double.parseDouble(fuelCapacityField.getText()));
                    ps.setString(6, ((TyreType)tyreTypeBox.getValue()).toString());
                    ps.setString(7, String.valueOf(selectedTruck.getId()));
                    ps.executeUpdate();
                } catch (SQLException var11) {
                    throw new RuntimeException(var11);
                }

                fxUtils.throwAlert("Updating truck info", "Updated");
            });

            try {
                this.truckListField.setItems(DbUtils.getDataTruck());
                this.truckComboBoxAvailable.setItems(DbUtils.getDataTruck());
            } catch (ClassNotFoundException var11) {
                throw new RuntimeException(var11);
            }

            this.truckListField.setItems(this.truckListField.getItems());
        }

    }


    public void deleteTruck() throws SQLException, ClassNotFoundException {
        Truck selectedTruck = (Truck)this.truckListField.getSelectionModel().getSelectedItem();
        Connection conn = DbUtils.connectToDb();
        PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM trucks WHERE id=?");
        preparedStatement.setInt(1, selectedTruck.getId());
        preparedStatement.executeUpdate();
        DbUtils.disconnect(conn, preparedStatement);
        this.truckListField.setItems(DbUtils.getDataTruck());
        this.truckComboBoxAvailable.setItems(DbUtils.getDataTruck());
    }

    public void createCargo() throws SQLException, ClassNotFoundException {
        try {
            if (!this.titleField.getText().isEmpty() && !this.weightField.getText().isEmpty() && !this.descriptionField.getText().isEmpty() && !this.customerField.getText().isEmpty() && this.dateCreatedField.getValue() != null) {
                double weight = Double.parseDouble(this.weightField.getText());
                LocalDate var3 = LocalDate.parse(((LocalDate)this.dateCreatedField.getValue()).toString());
            } else {
                LoginPage.alertDialog("Error", "All fields must be filled");
            }
        } catch (NumberFormatException var4) {
            LoginPage.alertDialog("Error", "Invalid input: " + var4.getMessage());
        } catch (DateTimeParseException var5) {
            LoginPage.alertDialog("Error", "Invalid date input: " + var5.getMessage());
        }

        Connection connection = DbUtils.connectToDb();
        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO cargos(title, dateCreated,weight,cargoType,description,customer) VALUES (?,?,?,?,?,?)");
        preparedStatement.setString(1, this.titleField.getText());
        preparedStatement.setString(2, String.valueOf(this.dateCreatedField.getValue()));
        preparedStatement.setDouble(3, Double.parseDouble(this.weightField.getText()));
        preparedStatement.setString(4, String.valueOf(this.cargoTypeField.getValue()));
        preparedStatement.setString(5, this.descriptionField.getText());
        preparedStatement.setString(6, this.customerField.getText());
        preparedStatement.execute();
        DbUtils.disconnect(connection, preparedStatement);
        this.cargoListField.setItems(DbUtils.getDataCargo());
        this.cargoComboBoxAvailable.setItems(DbUtils.getDataCargo());
    }

    public void updateCargo() {
        Connection conn = DbUtils.connectToDb();
        Cargo selectedCargo = this.cargoListField.getSelectionModel().getSelectedItem();
        if (selectedCargo != null) {
            TextField titleField = new TextField(selectedCargo.getTitle());
            DatePicker dateCreatedField = new DatePicker(selectedCargo.getDateCreated());
            TextField weightField = new TextField(Double.toString(selectedCargo.getWeight()));
            ComboBox<CargoType> cargoTypeBox = new ComboBox<>();
            cargoTypeBox.getItems().addAll(CargoType.values());
            cargoTypeBox.setValue(selectedCargo.getCargoType());
            TextField descriptionField = new TextField(selectedCargo.getDescription());
            TextField customerField = new TextField(selectedCargo.getCustomer());
            VBox vbox = new VBox(new Label("Title:"), titleField, new Label("Date Created:"), dateCreatedField, new Label("Weight:"), weightField, new Label("Cargo Type:"), cargoTypeBox, new Label("Description:"), descriptionField, new Label("Customer:"), customerField);
            fxUtils.updateItem(this.cargoListField, selectedCargo, "Update Cargo Information", vbox, () -> {
                PreparedStatement ps = null;

                try {
                    ps = conn.prepareStatement("UPDATE cargos SET title=?, dateCreated=?, weight=?, cargoType=?, description=?, customer=? WHERE id=?");
                    ps.setString(1, titleField.getText());
                    ps.setDate(2, java.sql.Date.valueOf((LocalDate)dateCreatedField.getValue()));
                    ps.setDouble(3, Double.parseDouble(weightField.getText()));
                    ps.setString(4, ((CargoType)cargoTypeBox.getValue()).toString());
                    ps.setString(5, descriptionField.getText());
                    ps.setString(6, customerField.getText());
                    ps.setString(7, String.valueOf(selectedCargo.getId()));
                    ps.executeUpdate();
                } catch (SQLException var11) {
                    throw new RuntimeException(var11);
                }

                fxUtils.throwAlert("Updating cargo info", "Updated");
            });

            try {
                this.cargoListField.setItems(DbUtils.getDataCargo());
                this.cargoComboBoxAvailable.setItems(DbUtils.getDataCargo());
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

            this.cargoListField.setItems(this.cargoListField.getItems());
        }

    }

    public void deleteCargo() throws SQLException, ClassNotFoundException {
        Connection conn = DbUtils.connectToDb();
        Cargo selectedCargo = (Cargo)this.cargoListField.getSelectionModel().getSelectedItem();
        PreparedStatement preparedStatement = conn.prepareStatement("DELETE FROM cargos WHERE id=?");
        preparedStatement.setInt(1, selectedCargo.getId());
        preparedStatement.executeUpdate();
        DbUtils.disconnect(conn, preparedStatement);
        this.cargoListField.setItems(DbUtils.getDataCargo());
        this.cargoComboBoxAvailable.setItems(DbUtils.getDataCargo());
    }

    public void createDestination() throws SQLException, ClassNotFoundException {
        try {
            if (!this.startLocField.getText().isEmpty() && !this.longitudeStartField.getText().isEmpty() && !this.latitudeStartField.getText().isEmpty() && !this.destinationLocField.getText().isEmpty() && !this.destinationLongitudeField.getText().isEmpty() && !this.destinationLatitudeField.getText().isEmpty()) {
                Long startLg = Long.parseLong(this.longitudeStartField.getText());
                Long startLatitude = Long.parseLong(this.latitudeStartField.getText());
                Long destinationLongitude = Long.parseLong(this.destinationLongitudeField.getText());
                Long var4 = Long.parseLong(this.destinationLatitudeField.getText());
            } else {
                LoginPage.alertDialog("Error", "All fields must be filled");
            }
        }
        catch (NumberFormatException var18) {
            LoginPage.alertDialog("Error", "Invalid input: " + var18.getMessage());
        }



        Destination destination = new Destination(this.startLocField.getText(), Long.parseLong(this.longitudeStartField.getText().toString()), Long.parseLong(this.latitudeStartField.getText().toString()), this.destinationLocField.getText().toString(), Long.parseLong(this.destinationLongitudeField.getText().toString()), Long.parseLong(this.destinationLatitudeField.getText().toString()), (Truck)this.truckComboBoxAvailable.getValue(), (Manager)this.responsibilityManager.getValue(), (Cargo)this.cargoComboBoxAvailable.getValue());
        Connection conn = DbUtils.connectToDb();

        PreparedStatement psCargo = conn.prepareStatement("SELECT id FROM cargos WHERE id=?");
        psCargo.setInt(1, destination.getCargo().getId());
        ResultSet rsCargo = psCargo.executeQuery();
        int idCargo = rsCargo.next() ? rsCargo.getInt("id") : 0;
        rsCargo.close();
        psCargo.close();

        PreparedStatement psTruck = conn.prepareStatement("SELECT id FROM trucks WHERE id=?");
        psTruck.setInt(1, destination.getTruck().getId());
        ResultSet rsTruck = psTruck.executeQuery();
        int idTruck = rsTruck.next() ? rsTruck.getInt("id") : 0;
        rsTruck.close();
        psTruck.close();

        PreparedStatement psManager = conn.prepareStatement("SELECT id FROM managers WHERE id=?");
        psManager.setInt(1, destination.getResponsibleManagers().getId());
        ResultSet rsManager = psManager.executeQuery();
        int idManager = rsManager.next() ? rsManager.getInt("id") : 0;
        rsManager.close();
        psManager.close();

        PreparedStatement psDestination = conn.prepareStatement("INSERT INTO destinations(startCity, startLn, startLat, endCity, endLn, endLat,truckId,responsibleManagersId, cargoId) VALUES (?,?,?,?,?,?,?,?,?)");
        psDestination.setString(1, destination.getStartCity());
        psDestination.setLong(2, destination.getStartLn());
        psDestination.setLong(3, destination.getStartLat());
        psDestination.setString(4, destination.getEndCity());
        psDestination.setLong(5, destination.getEndLn());
        psDestination.setLong(6, destination.getEndLat());
        psDestination.setInt(7, idTruck);
        psDestination.setInt(8, idManager);
        psDestination.setInt(9, idCargo);
        psDestination.execute();
        psDestination.close();
        PreparedStatement psDestinationGet = conn.prepareStatement("SELECT id FROM destinations WHERE truckId=? AND cargoId=?");
        psDestinationGet.setInt(1, idTruck);
        psDestinationGet.setInt(2, idCargo);
        ResultSet rsDestinationGet = psDestinationGet.executeQuery();
        int idDestination = rsDestinationGet.next() ? rsDestinationGet.getInt("id") : 0;
        rsDestinationGet.close();
        psDestinationGet.close();
        PreparedStatement psCargoUpdate = conn.prepareStatement("UPDATE cargos SET destinationId=? WHERE id=?");
        psCargoUpdate.setInt(1, idDestination);
        psCargoUpdate.setInt(2, idCargo);
        psCargoUpdate.executeUpdate();
        psCargoUpdate.close();
        PreparedStatement psTruckUpdate = conn.prepareStatement("UPDATE trucks SET destinationId=? WHERE id=?");
        psTruckUpdate.setInt(1, idDestination);
        psTruckUpdate.setInt(2, idTruck);
        psTruckUpdate.executeUpdate();
        psTruckUpdate.close();
        this.destinationListField.setItems(DbUtils.getDataDestination());
        this.destinationDisable();
    }

    public void updateDestination() throws ClassNotFoundException, SQLException {
        Destination selectedDestination = (Destination)this.destinationListField.getSelectionModel().getSelectedItem();
        if (selectedDestination == null) {
            fxUtils.throwAlert("Error", "Please select a destination to update.");
        } else {
            TextField startCityField = new TextField(selectedDestination.getStartCity());
            TextField startLNField = new TextField(String.valueOf(selectedDestination.getStartLn()));
            TextField startLatField = new TextField(String.valueOf(selectedDestination.getStartLat()));
            TextField endCityField = new TextField(selectedDestination.getEndCity());
            TextField endLNField = new TextField(String.valueOf(selectedDestination.getEndLn()));
            TextField endLatField = new TextField(String.valueOf(selectedDestination.getEndLat()));
            ChoiceBox<Truck> truckChoiceBox = new ChoiceBox<>(DbUtils.getDataTruck());
            truckChoiceBox.getSelectionModel().select(0);
            ChoiceBox<Cargo> cargoChoiceBox = new ChoiceBox<>(DbUtils.getDataCargo());
            cargoChoiceBox.getSelectionModel().select(0);
            ChoiceBox<Manager> managerChoiceBox = new ChoiceBox<>(DbUtils.getDataManagers());
            managerChoiceBox.getSelectionModel().select(0);
            VBox vbox = new VBox(new Label("Start City:"), startCityField, new Label("Start Longitude:"), startLNField, new Label("Start Latitude:"), startLatField, new Label("End City:"), endCityField, new Label("End Longitude:"), endLNField, new Label("End Latitude:"), endLatField, new Label("Truck"), truckChoiceBox, new Label("Cargo"), cargoChoiceBox, new Label("Manager"), managerChoiceBox);
            fxUtils.updateItem(this.destinationListField, selectedDestination, "Update Destination Information", vbox, () -> {
                Connection conn = DbUtils.connectToDb();
                PreparedStatement psGetCargoTruckId = null;
                if (!startCityField.getText().isEmpty() && !startLNField.getText().isEmpty() && !startLatField.getText().isEmpty() && !endCityField.getText().isEmpty() && !endLNField.getText().isEmpty() && !endLatField.getText().isEmpty()) {
                    try {
                        psGetCargoTruckId = conn.prepareStatement("SELECT truckId, cargoId FROM destinations WHERE id=?");
                        psGetCargoTruckId.setInt(1, selectedDestination.getId());
                        ResultSet rsGetTruckCargoId = psGetCargoTruckId.executeQuery();
                        int truckId = 0;
                        int cargoId = 0;

                        while(true) {
                            if (!rsGetTruckCargoId.next()) {
                                System.out.println(truckId);
                                System.out.println(cargoId);
                                rsGetTruckCargoId.close();
                                psGetCargoTruckId.close();
                                PreparedStatement psDestinationUpdate = conn.prepareStatement("UPDATE destinations SET startCity=?, startLn=?, startLat=?, endCity=?, endLn=?, endLat=?, truckId=?,responsibleManagersId=?, cargoId=? WHERE id=?");
                                psDestinationUpdate.setString(1, startCityField.getText());
                                psDestinationUpdate.setLong(2, Long.parseLong(startLNField.getText()));
                                psDestinationUpdate.setLong(3, Long.parseLong(startLatField.getText()));
                                psDestinationUpdate.setString(4, endCityField.getText());
                                psDestinationUpdate.setLong(5, Long.parseLong(endLNField.getText()));
                                psDestinationUpdate.setLong(6, Long.parseLong(endLatField.getText()));
                                psDestinationUpdate.setInt(7, ((Truck)truckChoiceBox.getValue()).getId());
                                psDestinationUpdate.setInt(8, ((Cargo)cargoChoiceBox.getValue()).getId());
                                psDestinationUpdate.setInt(9, ((Manager)managerChoiceBox.getValue()).getId());
                                psDestinationUpdate.setInt(10, selectedDestination.getId());
                                psDestinationUpdate.executeUpdate();
                                psDestinationUpdate.close();
                                PreparedStatement psIdDestinationDeleteFromCargo;
                                PreparedStatement psDestinationIdAddToCargo;
                                if (truckId != ((Truck)truckChoiceBox.getValue()).getId()) {
                                    psIdDestinationDeleteFromCargo = conn.prepareStatement("UPDATE trucks SET destinationId=NULL WHERE id=?");
                                    psIdDestinationDeleteFromCargo.setInt(1, truckId);
                                    psIdDestinationDeleteFromCargo.executeUpdate();
                                    psIdDestinationDeleteFromCargo.close();
                                    psDestinationIdAddToCargo = conn.prepareStatement("UPDATE trucks SET destinationId=? WHERE id=?");
                                    psDestinationIdAddToCargo.setInt(1, selectedDestination.getId());
                                    psDestinationIdAddToCargo.setInt(2, ((Truck)truckChoiceBox.getValue()).getId());
                                    psDestinationIdAddToCargo.executeUpdate();
                                    psDestinationIdAddToCargo.close();
                                }

                                if (cargoId != ((Cargo)cargoChoiceBox.getValue()).getId()) {
                                    psIdDestinationDeleteFromCargo = conn.prepareStatement("UPDATE cargos SET destinationId=NULL WHERE id=?");
                                    psIdDestinationDeleteFromCargo.setInt(1, cargoId);
                                    psIdDestinationDeleteFromCargo.executeUpdate();
                                    psIdDestinationDeleteFromCargo.close();
                                    psDestinationIdAddToCargo = conn.prepareStatement("UPDATE cargos SET destinationId=? WHERE id=?");
                                    psDestinationIdAddToCargo.setInt(1, selectedDestination.getId());
                                    psDestinationIdAddToCargo.setInt(2, ((Cargo)cargoChoiceBox.getValue()).getId());
                                    psDestinationIdAddToCargo.executeUpdate();
                                    psDestinationIdAddToCargo.close();
                                }

                                conn.close();
                                break;
                            }

                            truckId = rsGetTruckCargoId.getInt("truckId");
                            cargoId = rsGetTruckCargoId.getInt("cargoId");
                        }
                    } catch (SQLException var19) {
                        throw new RuntimeException(var19);
                    }

                    fxUtils.throwAlert("Updating destination info", "Updated");
                } else {
                    fxUtils.throwAlert("error", "Write text in field");
                }
            });
            this.destinationListField.setItems(DbUtils.getDataDestination());
            this.destinationDisable();
        }
    }

    public void deleteDestination() throws SQLException, ClassNotFoundException {
        Connection conn = DbUtils.connectToDb();
        Destination selectedDestination = (Destination)this.destinationListField.getSelectionModel().getSelectedItem();
        System.out.println(selectedDestination);
        if (selectedDestination != null) {
            int idDestination = selectedDestination.getId();
            PreparedStatement psTruck = conn.prepareStatement("UPDATE trucks SET trucks.destinationId=NULL WHERE destinationId=?");
            psTruck.setInt(1, idDestination);
            psTruck.executeUpdate();
            PreparedStatement psCargo = conn.prepareStatement("UPDATE cargos SET cargos.destinationId=NULL WHERE destinationId=?");
            psCargo.setInt(1, idDestination);
            psCargo.executeUpdate();
            System.out.println(idDestination);
            PreparedStatement psDestination = conn.prepareStatement("DELETE FROM destinations WHERE id=?");
            psDestination.setInt(1, idDestination);
            psDestination.executeUpdate();
            DbUtils.disconnect(conn, psDestination);
            this.destinationListField.setItems(DbUtils.getDataDestination());
            this.destinationDisable();
        }

    }

    public void destinationDisable() throws ClassNotFoundException, SQLException {
        this.truckComboBoxAvailable.setItems(DbUtils.getDataTruck());
        this.truckComboBoxAvailable.getSelectionModel().select(0);
        this.cargoComboBoxAvailable.setItems(DbUtils.getDataCargo());
        this.cargoComboBoxAvailable.getSelectionModel().select(0);
        this.cargoListField.setItems(DbUtils.getDataCargo());
        this.truckListField.setItems(DbUtils.getDataTruck());
    }

    public void addCheckpoint() throws SQLException {
        if (this.checkpointLocField.getText().isEmpty()) {
            fxUtils.throwAlert("error", "Write text in field");
        } else {
            Destination selectDestination = this.destinationListField.getSelectionModel().getSelectedItem();
            if (selectDestination != null) {
                Connection conn = DbUtils.connectToDb();
                PreparedStatement psCheckpointAdd = conn.prepareStatement("INSERT INTO checkpoints(title, longStop, dateArrived, destinationId) VALUE (?,?,?,?)");
                psCheckpointAdd.setString(1, this.checkpointLocField.getText());
                psCheckpointAdd.setBoolean(2, this.radioLong.isSelected());
                psCheckpointAdd.setDate(3, java.sql.Date.valueOf((LocalDate)this.destinationDateCreatedField.getValue()));
                psCheckpointAdd.setInt(4, selectDestination.getId());
                psCheckpointAdd.execute();
                DbUtils.disconnect(conn, psCheckpointAdd);
                this.checkpointListField.setItems(DbUtils.getDataCheckpoint(selectDestination));
            } else {
                fxUtils.throwAlert("Error", "Select destination");
            }

        }
    }

    public void updateCheckpoint() {
        Checkpoint selectedCheckpoint = (Checkpoint)this.checkpointListField.getSelectionModel().getSelectedItem();
        if (selectedCheckpoint == null) {
            fxUtils.throwAlert("Error", "Please select a destination to update.");
        } else {
            Connection conn = DbUtils.connectToDb();
            TextField titleField = new TextField(selectedCheckpoint.getTitle());
            DatePicker dateArriveField = new DatePicker(selectedCheckpoint.getDateArrived());
            VBox vbox = new VBox(new Label("Title:"), titleField, new Label("Date Arrive:"), dateArriveField);
            fxUtils.updateItem(this.checkpointListField, selectedCheckpoint, "Update Checkpoint Information", vbox, () -> {
                selectedCheckpoint.setTitle(titleField.getText());
                selectedCheckpoint.setDateArrived((LocalDate)dateArriveField.getValue());

                try {
                    PreparedStatement ps = conn.prepareStatement("UPDATE checkpoints SET title=?, dateArrived=? WHERE id=?");
                    ps.setString(1, titleField.getText());
                    ps.setDate(2, java.sql.Date.valueOf((LocalDate)dateArriveField.getValue()));
                    ps.setInt(3, selectedCheckpoint.getId());
                    ps.executeUpdate();
                } catch (SQLException var5) {
                    throw new RuntimeException(var5);
                }

                fxUtils.throwAlert("Updating checkpoint info", "Updated");
            });
            this.checkpointListField.refresh();
        }
    }

    public void deleteCheckpoint() throws SQLException {
        Connection conn = DbUtils.connectToDb();
        Destination selectDestination = (Destination)this.destinationListField.getSelectionModel().getSelectedItem();
        Checkpoint selectedCheckpoint = (Checkpoint)this.checkpointListField.getSelectionModel().getSelectedItem();
        PreparedStatement ps = conn.prepareStatement("DELETE FROM checkpoints WHERE id=?");
        ps.setInt(1, selectedCheckpoint.getId());
        ps.executeUpdate();
        DbUtils.disconnect(conn, ps);
        this.checkpointListField.setItems(DbUtils.getDataCheckpoint(selectDestination));
    }

    public void goToForum() throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(LoginPage.class.getResource("../view/forum-page.fxml"));
        Scene scene = new Scene((Parent)fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Forum page");
        stage.setScene(scene);
        stage.show();
    }

    public void showCheckpointInfo() throws SQLException {
        Destination selectedDestination = (Destination)this.destinationListField.getSelectionModel().getSelectedItem();
        if (selectedDestination != null) {
            this.checkpointListField.setItems(DbUtils.getDataCheckpoint(selectedDestination));
        }

    }
}
